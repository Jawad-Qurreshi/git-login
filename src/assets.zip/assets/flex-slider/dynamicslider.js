$(document).ready(function () {
  $('.flexslider').flexslider({
    animation: "slide"
  });
});